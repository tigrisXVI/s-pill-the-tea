# Pezzi di prova della Scatoletta Blistra v0.8

Stampali prima della scatola intera: in poche ore scopri se lamelle, sportellini e bilancia funzionano. Le STL sono già girate nel verso giusto: mettile sul piano così come sono.

## Impostazioni (PETG, ugello 0,4 mm)

| File | Materiale | Strato | Riempimento | Supporti |
|---|---|---|---|---|
| prova1_ruota.stl | PETG | 0,2 mm | 25 % | no |
| prova1_cassetta.stl | PETG | 0,2 mm | 25 % | no |
| prova1_sportellini.stl | PETG (meglio trasparente) | 0,12 mm | 100 % | no |
| prova1_lamelle_TPU.stl | TPU 95A, piano | 0,2 mm | 100 % | no |
| prova2_piattino.stl | PETG | 0,2 mm | 30 % | no |
| prova2_staffa.stl | PETG | 0,2 mm | 40 % | no |
| prova2_base_cella.stl | PETG | 0,2 mm | 30 % | no |

Valori di partenza per il PETG: ugello 235-240 °C, piano 75-80 °C, ventola 30-50 %, 3 perimetri. Per il TPU: 25 mm/s, niente retrazione o quasi.

Se hai poco filamento, stampa prima solo la **prova 1** (circa 30 g).

## Prova 1: lo spicchio di ruota

Ti servono un pezzetto di filo da 0,8 mm (una graffetta raddrizzata) per le cerniere degli sportellini, e pillole vere o perline da 3 mm.

1. Infila le lamelle di TPU nelle fessure in punta ai divisori.
2. Monta lo spicchio di ruota sull'asse della cassetta.
3. Metti le pillole negli scomparti, anche quelle piccolissime, e chiudi gli sportellini.
4. Gira la ruota avanti e indietro 20 volte, piano e poi veloce.
5. Controlla e segna:
   - passa qualcosa tra la ruota e l'anello? (non deve)
   - lo scomparto vicino all'uscita si svuota da solo? (non deve)
   - quando lo scomparto è sopra l'uscita, cadono tutte le pillole? (devono)
   - la ruota gira senza forzare con le lamelle? (sì, deve girare con un dito)
   - gli sportellini restano chiusi quando giri la ruota a testa in giù?

## Prova 2: il piattino pesato

Ti servono la cella da 100 g, l'HX711, l'ESP32 e due viti M2,5.

1. Avvita la cella sulla base dalla parte fissa (quella dei fili).
2. Metti la staffa sull'altra estremità e il piattino sulla staffa, con il perno.
3. Carica l'esempio HX711 della libreria Arduino "HX711" e taralo con una moneta da 1 € (7,5 g).
4. Pesa 10 volte la stessa pillola da circa 90 mg e 10 volte una piccolissima, e scrivi i numeri.
   - Se le 10 misure stanno entro ±10 mg: la bilancia va bene.
   - Se ballano di più: proviamo la cella da 50 g, o una media su più letture.

Mandami i risultati (anche foto): correggo il modello prima di stampare la scatola intera.
